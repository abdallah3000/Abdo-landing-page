
// adminster shifting bar for moving in page and getting information about each topic 
// it's important to define those variables to mention them later in code 
// and no need to define them each time 
// shifting bar variable is for the list of navigation menu so
// you can reach each topic 
// shiftingBar adminstration as constant variable 
const shiftingBar = document.getElementById("navbar__list");  

// adminstration of types for each topic 
// can be numbered and modified from index.HTML
// you can add as much as you want
// you can add new topic with a new topic numbered 
// with the content you want but 
// not from this file 
// index.HTML add the topic with the new numbered section
// types adminstration as constant variable  
// so can't be changed its value during the code 

const types = document.querySelectorAll("section");  


// adminstration of makeTypes

// adminstration of makeTypes as constant variable
// so can't be changed over and over

// this adminstration ensure making of regular list
const makeTypes = () => {
    // adminstration of roster 
    // as a changing variable so 
    // can be changed over and along the code
    // it has a different value each time it's processed
    let roster='';
    // bringing its value from index.HTML 
    // specifically from section and 
    // each section has its rule that can be changed for each one 
    // selecting all types for type can be
    // ...
    document.querySelectorAll("section").forEach(section => {

        // changing the value of roster and adding +1 each
    // section according their ID and navDataSet so 
    // adding and creating new items based on that information
       
        roster += `<li><a class="menu__link" href="#${section.id}">${section.dataset.nav}</a></li>`;
    

});

// adding after all that value of roster with all its changing items 
// and numbers after all that you add them to shiftingBar value 
// so new items can be created and numbered 
shiftingBar.innerHTML = roster;

};
// adminstration of makeTypes so can be used
// if not defined won't work in your code and
// it's an important step to define makeTypes 
// remember in future
makeTypes();


// differentiate between active and passive and adding style to differentiate between them
// doing that by adminstration of a function called typeViewed to check if the type is viewed 
// by getBoundingClientRect method so cand detect whether the type is in view or not
// so we can decide and let the code decide which type is active and which is not
// ...

function typeViewed (motif) {
    // adminstration of typePlace as changing  variable so 
    // it's not a constant value but it's changed over and over 
    // according to the value given by getBoundingClientRect method to take the values of its place 
    // on  the web page and know or even decide as they call it's active 
    // ...
    // this adminstration for each type is different according to their position 
    let typePlace = motif.getBoundingClientRect();
    // ...
    // after that adminstration we have a value we should return
    // so can be used to define its boundings of each type
    // we return then the place of each type as equal or higher than 0
    // ...
    // it's essential to return the value 
    // remember that 
    return (typePlace.top>= 0);
}
// our typeViewed function  now valid to work in the rest of the code 
// adminstration of a new function called switchingOnType 
// adding looping state for of 
// for each type of the types we check if it's viewed or not 
// so if it's right 
// that means it's active and then we switch on 
function switchingOnType() {
    // adding looping for of state 
    // for each one we check if active or not 
    // if active we apply a selective color
    // this color of course is according to your preference 
    // if not active it's passive 
    for (type of types) {
        // starting for loop
        // we add if to check type is viewed 
        // we get the information from our classList if 
        // not contains your-active-class 
        // so add your-active-class to the type 
        // and to differentiate 
        // ...
        // ...
        if (typeViewed(type))  {
            // if 
        // not contains your-active-class 
        // so add your-active-class to the type
            if (!type.classList.contains('your-active-class')) {
                // add your-active-class to the type after calling it from classList
                // of course we add active if not contain the active state
                // ...
                // ...
                // we then add your-active-class to the type not 
                // containing it 
                // attention please to this point it can be a bit tricky 
                // so pay attention where you add activeClass
                type.classList.add('your-active-class');
                // here we differentiate the activeClass from non-activeClass by
                // adding style to type bounding and background color 
                // and changing it to a color of our taste 
                // i chose grey 
                // of course you can change it any time you want
                // and test it to your liking 
                // play and enjoy 
                //...
                type.style.cssText = "background-color: grey;";
                // the color changed to grey :)
            }
        }
        // if not containing we do the steps above and 
        // if containing we remove it so it's not
        // here we process else state to remove your-active-class from 
        // the type containing 
        // ...
        // we for sure need to differentiate as before the active one from not active one
        // we will get to very soon 
        else{
            type.classList.remove('your-active-class');
            // tada we removed your-active-class but 
            // how to know that on the web page 
            // we can't but we'll add a style the same as the page gradient color 
            // so it's clear that it's not selected 
            // ...
            type.style.cssText = "background-color: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%)";
        }
    }
}

// using a simple method to activate our function according our scrolling position
// to initiate an event we should scroll :)))
// activate function upon event
window.onscroll = switchingOnType;
