# General Information
landing page project

## name
Abdallah Mohamed Mostafa
VS code

## languages used in the project:
HTML
CSS
JAVASCRIPT

## The Functionalities

navigation in dynamic way
scrolling effect

## project importance to me
 
 I learned a lot about page design and customization with adding dynamic effects to design 
